ALTER TABLE `orders` ADD `address` text NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `city` varchar(100) NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `state` varchar(2) NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `zipCode` varchar(10) NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `shippingMethod` enum('sedex','pac','pickup') NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `paymentMethod` enum('credit_card','pix','boleto','mercado_pago') NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `shippingCost` decimal(10,2) DEFAULT '0' NOT NULL;