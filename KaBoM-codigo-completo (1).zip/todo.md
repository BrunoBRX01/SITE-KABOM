# TechParts - Todo List

## Banco de Dados
- [x] Criar tabelas: products, categories, orders, order_items
- [x] Implementar relacionamentos entre tabelas
- [x] Executar migrações SQL
- [x] Popular banco com categorias e produtos iniciais

## Backend (tRPC Routers)
- [x] Implementar router de produtos (listar, criar, atualizar, deletar)
- [x] Implementar router de categorias (listar)
- [x] Implementar router de pedidos (criar, listar, atualizar status)
- [x] Implementar proteção de rotas administrativas

## Frontend - Loja
- [x] Página inicial (Home) com hero section e produtos em destaque
- [x] Página de catálogo com filtro por categoria
- [x] Página de carrinho de compras com localStorage
- [x] Fluxo de checkout com confirmação
- [x] Integração com tRPC para dados de produtos

## Frontend - Painel Administrativo
- [x] Autenticação via Manus OAuth
- [x] Dashboard administrativo
- [x] Gerenciamento de produtos (visualizar e deletar)
- [x] Gerenciamento de pedidos (visualizar e atualizar status)
- [x] Proteção de rotas administrativas

## Design & Styling
- [x] Configurar tema dark tech com Tailwind CSS
- [x] Implementar design responsivo
- [x] Criar componentes reutilizáveis
- [x] Estilizar navegação principal
- [x] Estilizar painel administrativo
- [x] Ajustar cores e temas finais
- [x] Implementar checkout com página dedicada e validação
- [x] Conectar exclusão de produto no CMS
- [x] Implementar navegação mobile funcional (menu hamburger)

## Testes & Validação
- [x] Testes unitários com Vitest (12 testes passando)
- [x] Fluxo de compra funcional (Carrinho -> Checkout -> Confirmação)
- [x] Painel administrativo funcional (visualizar, deletar produtos, atualizar status pedidos)
- [x] Design responsivo implementado

## Deploy
- [x] Criar checkpoint final
- [x] Deploy da aplicação
- [x] Gerar URL permanente
- [x] Atualizar nome do site para KaBoM

## Funcionalidades Adicionais
- [x] Foreign keys implementadas no banco de dados
- [x] Header com navegação responsiva
- [x] Carrinho persistente com localStorage
- [x] Integração completa de pedidos
- [x] Tema dark tech com Tailwind CSS
- [x] População inicial de dados

## Novas Funcionalidades Solicitadas
- [x] Página de detalhes do produto (clique no item)
- [x] Formulário expandido no checkout (endereço, entrega, pagamento)
- [x] Atualizar schema para armazenar informações de entrega
- [x] Opções de entrega (Sedex, PAC, Retirada)
- [x] Métodos de pagamento (Cartão, Pix, Boleto, Mercado Pago)
- [x] Validação de formulário de endereço
- [x] Testes para novo fluxo de checkout
