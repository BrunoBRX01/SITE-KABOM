import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const categories = [
  { name: 'Processadores', description: 'CPUs e processadores de alta performance' },
  { name: 'Placas de Vídeo', description: 'GPUs para gaming e criação de conteúdo' },
  { name: 'Memórias', description: 'RAM DDR4 e DDR5' },
  { name: 'Placas-mãe', description: 'Placas-mãe para diferentes plataformas' },
  { name: 'Armazenamento', description: 'SSDs e HDDs' },
  { name: 'Fontes', description: 'Fontes de alimentação certificadas' },
  { name: 'Gabinetes', description: 'Gabinetes para PC' },
];

const products = [
  {
    name: 'Intel Core i9-13900K',
    category: 'Processadores',
    price: '3499.90',
    stock: 15,
    description: '24 núcleos, 32 threads, até 5.8 GHz. Processador topo de linha para gaming e criação.',
    imageUrl: 'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'AMD Ryzen 9 7950X',
    category: 'Processadores',
    price: '3299.90',
    stock: 12,
    description: '16 núcleos, 32 threads, até 5.7 GHz. Excelente para multitarefa.',
    imageUrl: 'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'NVIDIA RTX 4090',
    category: 'Placas de Vídeo',
    price: '12999.00',
    stock: 5,
    description: '24GB GDDR6X. A placa de vídeo mais poderosa do mercado.',
    imageUrl: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'NVIDIA RTX 4080',
    category: 'Placas de Vídeo',
    price: '7999.00',
    stock: 8,
    description: '16GB GDDR6X. Ótima para gaming em 4K.',
    imageUrl: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'Corsair Vengeance DDR5 32GB',
    category: 'Memórias',
    price: '899.00',
    stock: 25,
    description: '2x16GB, 6000MHz. Alta performance para sistemas modernos.',
    imageUrl: 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'Kingston Fury Beast DDR5 32GB',
    category: 'Memórias',
    price: '799.00',
    stock: 20,
    description: '2x16GB, 5600MHz. Ótima relação custo-benefício.',
    imageUrl: 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'ASUS ROG STRIX Z790',
    category: 'Placas-mãe',
    price: '1999.00',
    stock: 10,
    description: 'Socket LGA1700, PCIe 5.0. Placa premium para Intel.',
    imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'MSI MPG B850E',
    category: 'Placas-mãe',
    price: '1799.00',
    stock: 8,
    description: 'Socket AM5, PCIe 5.0. Placa premium para AMD.',
    imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'Samsung 990 Pro 4TB',
    category: 'Armazenamento',
    price: '2999.00',
    stock: 15,
    description: 'NVMe PCIe 4.0, velocidade até 7.1 GB/s.',
    imageUrl: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'WD Black SN850X 2TB',
    category: 'Armazenamento',
    price: '1499.00',
    stock: 20,
    description: 'NVMe PCIe 4.0, velocidade até 7.1 GB/s.',
    imageUrl: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'Corsair RM1000x 1000W',
    category: 'Fontes',
    price: '1299.00',
    stock: 12,
    description: 'Modular, 80+ Gold, 10 anos de garantia.',
    imageUrl: 'https://images.unsplash.com/photo-1609034227505-5876f6aa4e90?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'EVGA SuperNOVA 850W',
    category: 'Fontes',
    price: '999.00',
    stock: 18,
    description: 'Modular, 80+ Gold, certificada.',
    imageUrl: 'https://images.unsplash.com/photo-1609034227505-5876f6aa4e90?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'Lian Li LANCOOL 3',
    category: 'Gabinetes',
    price: '599.00',
    stock: 22,
    description: 'Mid-tower, suporta até 3 ventiladores, vidro temperado.',
    imageUrl: 'https://images.unsplash.com/photo-1587829191301-4b34e2e90e3d?auto=format&fit=crop&q=80&w=400',
  },
  {
    name: 'NZXT H7 Flow',
    category: 'Gabinetes',
    price: '699.00',
    stock: 16,
    description: 'Mid-tower, fluxo de ar otimizado, vidro temperado.',
    imageUrl: 'https://images.unsplash.com/photo-1587829191301-4b34e2e90e3d?auto=format&fit=crop&q=80&w=400',
  },
];

async function seed() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);

  try {
    console.log('Iniciando seed do banco de dados...');

    // Inserir categorias
    for (const category of categories) {
      await connection.execute(
        'INSERT INTO categories (name, description) VALUES (?, ?)',
        [category.name, category.description]
      );
    }
    console.log('✅ Categorias inseridas');

    // Obter IDs das categorias
    const [categoryRows] = await connection.execute('SELECT id, name FROM categories');
    const categoryMap = {};
    categoryRows.forEach(row => {
      categoryMap[row.name] = row.id;
    });

    // Inserir produtos
    for (const product of products) {
      const categoryId = categoryMap[product.category];
      await connection.execute(
        'INSERT INTO products (name, description, price, stock, categoryId, imageUrl, isActive) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [product.name, product.description, product.price, product.stock, categoryId, product.imageUrl, true]
      );
    }
    console.log('✅ Produtos inseridos');

    console.log('✅ Seed concluído com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao fazer seed:', error);
  } finally {
    await connection.end();
  }
}

seed();
