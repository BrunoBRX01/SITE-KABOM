import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, ShoppingCart } from "lucide-react";

// Viltrumita theme: Black with red and white accents
export default function Catalog() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const { data: products, isLoading } = trpc.products.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();

  const filteredProducts = selectedCategory
    ? products?.filter((p) => p.categoryId === selectedCategory)
    : products;

  const handleAddToCart = (product: any) => {
    const cart = JSON.parse(localStorage.getItem("techparts_cart") || "[]");
    const existingItem = cart.find((item: any) => item.id === product.id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        imageUrl: product.imageUrl,
      });
    }

    localStorage.setItem("techparts_cart", JSON.stringify(cart));
    alert(`${product.name} adicionado ao carrinho!`);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h1 className="mb-8 text-4xl font-bold text-white">Catálogo de Produtos</h1>

          <div className="grid gap-8 lg:grid-cols-4">
            {/* Sidebar - Categorias */}
            <div className="lg:col-span-1">
              <div className="rounded-lg border border-red-600/50 bg-gray-900/50 p-6 backdrop-blur">
                <h2 className="mb-4 text-lg font-semibold text-white">Categorias</h2>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory(null)}
                    className={`block w-full rounded px-3 py-2 text-left transition-colors ${
                      selectedCategory === null
                        ? "bg-red-600 text-white font-semibold"
                        : "text-gray-300 hover:bg-red-600/10 hover:text-red-500"
                    }`}
                  >
                    Todos
                  </button>
                  {categories?.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`block w-full rounded px-3 py-2 text-left transition-colors ${
                        selectedCategory === category.id
                          ? "bg-red-600 text-white font-semibold"
                          : "text-gray-300 hover:bg-red-600/10 hover:text-red-500"
                      }`}
                    >
                      {category.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Main Content - Produtos */}
            <div className="lg:col-span-3">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-red-600" />
                </div>
              ) : filteredProducts && filteredProducts.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredProducts.map((product) => (
                    <Card
                      key={product.id}
                      className="overflow-hidden border-red-600/50 bg-gray-900/50 backdrop-blur transition-all hover:border-red-600 hover:shadow-lg hover:shadow-red-600/20"
                    >
                      <div className="aspect-video overflow-hidden bg-gray-800">
                        <img
                          src={product.imageUrl || ""}
                          alt={product.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <p className="mb-2 text-sm text-red-600">{product.categoryId}</p>
                        <h3 className="mb-2 font-semibold text-white line-clamp-2">
                          {product.name}
                        </h3>
                        <p className="mb-2 text-sm text-gray-400 line-clamp-2">
                          {product.description}
                        </p>
                        <div className="mb-4 flex items-center justify-between">
                          <p className="text-2xl font-bold text-red-600">
                            R$ {parseFloat(product.price as any).toLocaleString("pt-BR", {
                              minimumFractionDigits: 2,
                            })}
                          </p>
                          <span
                            className={`text-sm font-semibold ${
                              product.stock > 0 ? "text-green-400" : "text-red-600"
                            }`}
                          >
                            {product.stock > 0 ? `${product.stock} em estoque` : "Fora de estoque"}
                          </span>
                        </div>
                        <div className="space-y-2">
                          <Link href={`/product/${product.id}`}>
                            <Button
                              variant="outline"
                              className="w-full border-red-600 text-red-600 hover:bg-red-600/10"
                            >
                              Ver Detalhes
                            </Button>
                          </Link>
                          <Button
                            className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold"
                            disabled={product.stock === 0}
                            onClick={() => handleAddToCart(product)}
                          >
                            <ShoppingCart className="mr-2 h-4 w-4" />
                            Adicionar ao Carrinho
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-red-600/50 bg-gray-900/50 p-12 text-center backdrop-blur">
                  <p className="text-gray-400">Nenhum produto encontrado nesta categoria</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
