import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Trash2, ShoppingBag } from "lucide-react";

// Viltrumita theme: Black with red and white accents
interface CartItem {
  id: number;
  name: string;
  price: string;
  quantity: number;
  imageUrl?: string;
}

export default function Cart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Carregar itens do localStorage
  useEffect(() => {
    const saved = localStorage.getItem("techparts_cart");
    if (saved) {
      try {
        setCartItems(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar carrinho:", e);
      }
    }
  }, []);

  // Salvar no localStorage quando mudar
  useEffect(() => {
    localStorage.setItem("techparts_cart", JSON.stringify(cartItems));
  }, [cartItems]);

  const handleRemove = (id: number) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const handleQuantityChange = (id: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemove(id);
    } else {
      setCartItems(
        cartItems.map((item) =>
          item.id === id ? { ...item, quantity } : item
        )
      );
    }
  };

  const total = cartItems.reduce(
    (sum, item) => sum + parseFloat(item.price) * item.quantity,
    0
  );

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      alert("Seu carrinho está vazio!");
      return;
    }
    // Redirecionar para página de checkout
    window.location.href = "/checkout";
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-black">
        <div className="px-4 py-12 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <ShoppingBag className="mx-auto mb-4 h-16 w-16 text-gray-600" />
            <h1 className="mb-4 text-3xl font-bold text-white">
              Seu carrinho está vazio
            </h1>
            <p className="mb-8 text-gray-400">
              Comece a adicionar produtos para montar seu setup perfeito
            </p>
            <Link href="/catalog">
              <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold">
                Voltar para Catálogo
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h1 className="mb-8 text-4xl font-bold text-white">Seu Carrinho</h1>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Itens do Carrinho */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <Card
                  key={item.id}
                  className="border-red-600/50 bg-gray-900/50 p-4 backdrop-blur"
                >
                  <div className="flex gap-4">
                    {item.imageUrl && (
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="h-24 w-24 rounded object-cover"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{item.name}</h3>
                      <p className="text-red-600 font-bold">
                        R$ {parseFloat(item.price).toLocaleString("pt-BR", {
                          minimumFractionDigits: 2,
                        })}
                      </p>
                      <div className="mt-4 flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              handleQuantityChange(item.id, item.quantity - 1)
                            }
                            className="rounded bg-gray-800 px-2 py-1 text-gray-300 hover:bg-red-600/20 hover:text-red-500"
                          >
                            −
                          </button>
                          <span className="w-8 text-center text-white">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              handleQuantityChange(item.id, item.quantity + 1)
                            }
                            className="rounded bg-gray-800 px-2 py-1 text-gray-300 hover:bg-red-600/20 hover:text-red-500"
                          >
                            +
                          </button>
                        </div>
                        <span className="text-gray-400">
                          Subtotal: R${" "}
                          {(parseFloat(item.price) * item.quantity).toLocaleString(
                            "pt-BR",
                            { minimumFractionDigits: 2 }
                          )}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemove(item.id)}
                      className="text-red-600 hover:text-red-500"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Resumo do Pedido */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24 border-red-600/50 bg-gray-900/50 p-6 backdrop-blur">
                <h2 className="mb-6 text-xl font-bold text-white">
                  Resumo do Pedido
                </h2>
                <div className="space-y-4 border-b border-gray-700 pb-4">
                  <div className="flex justify-between text-gray-300">
                    <span>Subtotal:</span>
                    <span>
                      R${" "}
                      {total.toLocaleString("pt-BR", {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Frete:</span>
                    <span>Grátis</span>
                  </div>
                </div>
                <div className="mt-4 flex justify-between text-lg font-bold text-red-600">
                  <span>Total:</span>
                  <span>
                    R${" "}
                    {total.toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                    })}
                  </span>
                </div>
                <Button
                  className="mt-6 w-full bg-red-600 hover:bg-red-700 text-white font-bold"
                  onClick={handleCheckout}
                >
                  Ir para Checkout
                </Button>
                <Link href="/catalog">
                  <Button
                    variant="outline"
                    className="mt-3 w-full border-red-600 text-red-600 hover:bg-red-600/10"
                  >
                    Continuar Comprando
                  </Button>
                </Link>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
