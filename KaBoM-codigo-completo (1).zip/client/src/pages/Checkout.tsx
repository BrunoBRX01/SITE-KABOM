import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { CheckCircle, AlertCircle } from "lucide-react";

interface CartItem {
  id: number;
  name: string;
  price: string;
  quantity: number;
  imageUrl?: string;
}

const SHIPPING_COSTS = {
  sedex: 50,
  pac: 20,
  pickup: 0,
};

export default function Checkout() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    shippingMethod: "sedex" as "sedex" | "pac" | "pickup",
    paymentMethod: "pix" as "credit_card" | "pix" | "boleto" | "mercado_pago",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderId, setOrderId] = useState<number | null>(null);

  const createOrderMutation = trpc.orders.create.useMutation();

  // Recuperar itens do carrinho
  const cartItems: CartItem[] = JSON.parse(
    localStorage.getItem("techparts_cart") || "[]"
  );

  if (cartItems.length === 0 && !orderConfirmed) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
        <div className="px-4 py-12 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <AlertCircle className="mx-auto mb-4 h-16 w-16 text-yellow-400" />
            <h1 className="mb-4 text-3xl font-bold text-white">
              Seu carrinho está vazio
            </h1>
            <Link href="/catalog">
              <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold">
                Voltar para Catálogo
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const subtotal = cartItems.reduce(
    (sum, item) => sum + parseFloat(item.price) * item.quantity,
    0
  );
  
  const shippingCost = SHIPPING_COSTS[formData.shippingMethod];
  const total = subtotal + shippingCost;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.customerName.trim()) {
      newErrors.customerName = "Nome é obrigatório";
    }
    if (!formData.customerEmail.trim()) {
      newErrors.customerEmail = "Email é obrigatório";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.customerEmail)) {
      newErrors.customerEmail = "Email inválido";
    }
    if (!formData.address.trim()) {
      newErrors.address = "Endereço é obrigatório";
    }
    if (!formData.city.trim()) {
      newErrors.city = "Cidade é obrigatória";
    }
    if (!formData.state.trim() || formData.state.length !== 2) {
      newErrors.state = "Estado deve ter 2 caracteres (ex: SP)";
    }
    if (!formData.zipCode.trim()) {
      newErrors.zipCode = "CEP é obrigatório";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const items = cartItems.map((item) => ({
      productId: item.id,
      quantity: item.quantity,
      priceAtPurchase: item.price,
    }));

    createOrderMutation.mutate(
      {
        customerName: formData.customerName,
        customerEmail: formData.customerEmail,
        customerPhone: formData.customerPhone || undefined,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        zipCode: formData.zipCode,
        shippingMethod: formData.shippingMethod,
        paymentMethod: formData.paymentMethod,
        shippingCost: shippingCost.toString(),
        items,
        totalAmount: total.toString(),
      },
      {
        onSuccess: (result: any) => {
          setOrderId(result);
          setOrderConfirmed(true);
          localStorage.removeItem("techparts_cart");
        },
        onError: (error) => {
          setErrors({ submit: `Erro ao criar pedido: ${error.message}` });
        },
      }
    );
  };

  if (orderConfirmed) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-red-950 to-black">
        <div className="px-4 py-12 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl">
            <Card className="border-red-600/50 bg-black/50 p-8 text-center backdrop-blur">
              <CheckCircle className="mx-auto mb-4 h-16 w-16 text-red-500" />
              <h1 className="mb-4 text-3xl font-bold text-white">
                Pedido Confirmado!
              </h1>
              <p className="mb-6 text-gray-300">
                Obrigado pela sua compra, {formData.customerName}!
              </p>
              <div className="mb-8 rounded-lg bg-red-950/30 p-4 text-left border border-red-600/30">
                <p className="mb-2 text-gray-400">
                  <span className="font-semibold text-white">Número do Pedido:</span> #{orderId}
                </p>
                <p className="mb-2 text-gray-400">
                  <span className="font-semibold text-white">Email de Confirmação:</span>{" "}
                  {formData.customerEmail}
                </p>
                <p className="mb-2 text-gray-400">
                  <span className="font-semibold text-white">Endereço de Entrega:</span>{" "}
                  {formData.address}, {formData.city} - {formData.state}
                </p>
                <p className="text-gray-400">
                  <span className="font-semibold text-white">Total:</span> R${" "}
                  {total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <p className="mb-8 text-gray-400">
                Você receberá um email com os detalhes do seu pedido em breve.
              </p>
              <Link href="/">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold">
                  Voltar para Início
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-red-950 to-black">
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h1 className="mb-8 text-4xl font-bold text-white">Checkout</h1>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Formulário */}
            <div className="lg:col-span-2">
              <Card className="border-red-600/30 bg-black/50 p-6 backdrop-blur">
                <h2 className="mb-6 text-2xl font-bold text-white">
                  Informações Pessoais
                </h2>

                {errors.submit && (
                  <div className="mb-4 rounded-lg bg-red-500/10 p-4 text-red-400 border border-red-600/30">
                    {errors.submit}
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Dados Pessoais */}
                  <div>
                    <h3 className="mb-4 text-lg font-semibold text-red-500">Dados Pessoais</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                          Nome Completo *
                        </label>
                        <input
                          type="text"
                          value={formData.customerName}
                          onChange={(e) =>
                            setFormData({ ...formData, customerName: e.target.value })
                          }
                          className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                            errors.customerName
                              ? "border-red-500"
                              : "border-red-600/30"
                          }`}
                          placeholder="João Silva"
                        />
                        {errors.customerName && (
                          <p className="mt-1 text-sm text-red-400">
                            {errors.customerName}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                          Email *
                        </label>
                        <input
                          type="email"
                          value={formData.customerEmail}
                          onChange={(e) =>
                            setFormData({ ...formData, customerEmail: e.target.value })
                          }
                          className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                            errors.customerEmail
                              ? "border-red-500"
                              : "border-red-600/30"
                          }`}
                          placeholder="joao@example.com"
                        />
                        {errors.customerEmail && (
                          <p className="mt-1 text-sm text-red-400">
                            {errors.customerEmail}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                          Telefone (Opcional)
                        </label>
                        <input
                          type="tel"
                          value={formData.customerPhone}
                          onChange={(e) =>
                            setFormData({ ...formData, customerPhone: e.target.value })
                          }
                          className="w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border border-red-600/30"
                          placeholder="(11) 99999-9999"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Endereço de Entrega */}
                  <div className="border-t border-red-600/30 pt-6">
                    <h3 className="mb-4 text-lg font-semibold text-red-500">Endereço de Entrega</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                          Endereço *
                        </label>
                        <input
                          type="text"
                          value={formData.address}
                          onChange={(e) =>
                            setFormData({ ...formData, address: e.target.value })
                          }
                          className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                            errors.address
                              ? "border-red-500"
                              : "border-red-600/30"
                          }`}
                          placeholder="Rua das Flores, 123"
                        />
                        {errors.address && (
                          <p className="mt-1 text-sm text-red-400">
                            {errors.address}
                          </p>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-white mb-2">
                            Cidade *
                          </label>
                          <input
                            type="text"
                            value={formData.city}
                            onChange={(e) =>
                              setFormData({ ...formData, city: e.target.value })
                            }
                            className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                              errors.city
                                ? "border-red-500"
                                : "border-red-600/30"
                            }`}
                            placeholder="São Paulo"
                          />
                          {errors.city && (
                            <p className="mt-1 text-sm text-red-400">
                              {errors.city}
                            </p>
                          )}
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-white mb-2">
                            Estado (UF) *
                          </label>
                          <input
                            type="text"
                            maxLength={2}
                            value={formData.state}
                            onChange={(e) =>
                              setFormData({ ...formData, state: e.target.value.toUpperCase() })
                            }
                            className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                              errors.state
                                ? "border-red-500"
                                : "border-red-600/30"
                            }`}
                            placeholder="SP"
                          />
                          {errors.state && (
                            <p className="mt-1 text-sm text-red-400">
                              {errors.state}
                            </p>
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-white mb-2">
                          CEP *
                        </label>
                        <input
                          type="text"
                          value={formData.zipCode}
                          onChange={(e) =>
                            setFormData({ ...formData, zipCode: e.target.value })
                          }
                          className={`w-full rounded bg-slate-900 px-4 py-2 text-white placeholder-slate-500 border ${
                            errors.zipCode
                              ? "border-red-500"
                              : "border-red-600/30"
                          }`}
                          placeholder="01234-567"
                        />
                        {errors.zipCode && (
                          <p className="mt-1 text-sm text-red-400">
                            {errors.zipCode}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Opções de Entrega */}
                  <div className="border-t border-red-600/30 pt-6">
                    <h3 className="mb-4 text-lg font-semibold text-red-500">Forma de Entrega</h3>
                    <div className="space-y-3">
                      {(["sedex", "pac", "pickup"] as const).map((method) => (
                        <label key={method} className="flex items-center p-3 rounded border border-red-600/30 cursor-pointer hover:bg-red-950/20 transition">
                          <input
                            type="radio"
                            name="shipping"
                            value={method}
                            checked={formData.shippingMethod === method}
                            onChange={(e) =>
                              setFormData({ ...formData, shippingMethod: e.target.value as any })
                            }
                            className="mr-3"
                          />
                          <div className="flex-1">
                            <p className="font-semibold text-white">
                              {method === "sedex" && "SEDEX (2-3 dias)"}
                              {method === "pac" && "PAC (5-7 dias)"}
                              {method === "pickup" && "Retirada na Loja"}
                            </p>
                            <p className="text-sm text-gray-400">
                              R$ {SHIPPING_COSTS[method].toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Forma de Pagamento */}
                  <div className="border-t border-red-600/30 pt-6">
                    <h3 className="mb-4 text-lg font-semibold text-red-500">Forma de Pagamento</h3>
                    <div className="space-y-3">
                      {(["pix", "credit_card", "boleto", "mercado_pago"] as const).map((method) => (
                        <label key={method} className="flex items-center p-3 rounded border border-red-600/30 cursor-pointer hover:bg-red-950/20 transition">
                          <input
                            type="radio"
                            name="payment"
                            value={method}
                            checked={formData.paymentMethod === method}
                            onChange={(e) =>
                              setFormData({ ...formData, paymentMethod: e.target.value as any })
                            }
                            className="mr-3"
                          />
                          <div>
                            <p className="font-semibold text-white">
                              {method === "pix" && "PIX"}
                              {method === "credit_card" && "Cartão de Crédito"}
                              {method === "boleto" && "Boleto"}
                              {method === "mercado_pago" && "Mercado Pago"}
                            </p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="border-t border-red-600/30 pt-6">
                    <Button
                      type="submit"
                      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold"
                      disabled={createOrderMutation.isPending}
                    >
                      {createOrderMutation.isPending
                        ? "Processando..."
                        : "Confirmar Pedido"}
                    </Button>
                  </div>
                </form>
              </Card>
            </div>

            {/* Resumo do Pedido */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24 border-red-600/30 bg-black/50 p-6 backdrop-blur">
                <h2 className="mb-6 text-xl font-bold text-white">
                  Resumo do Pedido
                </h2>

                <div className="mb-6 space-y-3 border-b border-red-600/30 pb-6">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-gray-300">
                        {item.name} x {item.quantity}
                      </span>
                      <span className="text-red-500 font-semibold">
                        R${" "}
                        {(parseFloat(item.price) * item.quantity).toLocaleString(
                          "pt-BR",
                          { minimumFractionDigits: 2 }
                        )}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between text-gray-300">
                    <span>Subtotal:</span>
                    <span>
                      R${" "}
                      {subtotal.toLocaleString("pt-BR", {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Frete:</span>
                    <span>
                      R${" "}
                      {shippingCost.toLocaleString("pt-BR", {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                </div>

                <div className="mt-4 border-t border-red-600/30 pt-4 flex justify-between text-lg font-bold text-red-500">
                  <span>Total:</span>
                  <span>
                    R${" "}
                    {total.toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                    })}
                  </span>
                </div>

                <Link href="/cart">
                  <Button
                    variant="outline"
                    className="mt-4 w-full border-red-600 text-red-500 hover:bg-red-600/10"
                  >
                    Voltar para Carrinho
                  </Button>
                </Link>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
