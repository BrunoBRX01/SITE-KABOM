import { useState } from "react";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ShoppingCart, AlertCircle } from "lucide-react";

export default function ProductDetail() {
  const [match, params] = useRoute("/product/:id");
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  const productId = params?.id ? parseInt(params.id) : null;
  const { data: product, isLoading, error } = trpc.products.getById.useQuery(
    productId!,
    { enabled: !!productId }
  );

  if (!match) return null;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-red-950 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
          <p className="mt-4 text-white">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-red-950 to-black">
        <div className="px-4 py-12 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <AlertCircle className="mx-auto mb-4 h-16 w-16 text-red-500" />
            <h1 className="mb-4 text-3xl font-bold text-white">
              Produto não encontrado
            </h1>
            <Link href="/catalog" asChild>
              <Button className="bg-red-600 hover:bg-red-700 text-white font-bold">
                Voltar para Catálogo
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    const cart = JSON.parse(localStorage.getItem("techparts_cart") || "[]");
    const existingItem = cart.find((item: any) => item.id === product.id);

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity,
        imageUrl: product.imageUrl,
      });
    }

    localStorage.setItem("techparts_cart", JSON.stringify(cart));
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-red-950 to-black">
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          {/* Botão Voltar */}
          <Link href="/catalog">
            <Button variant="ghost" className="mb-8 text-gray-300 hover:text-red-500">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para Catálogo
            </Button>
          </Link>

          <div className="grid gap-8 lg:grid-cols-2">
            {/* Imagem do Produto */}
            <div>
              <Card className="border-red-600/30 bg-black/50 p-8 backdrop-blur">
                {product.imageUrl ? (
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-96 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-full h-96 bg-gradient-to-br from-red-950 to-black rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Sem imagem disponível</p>
                  </div>
                )}
              </Card>
            </div>

            {/* Informações do Produto */}
            <div>
              <Card className="border-red-600/30 bg-black/50 p-8 backdrop-blur">
                <h1 className="mb-4 text-4xl font-bold text-white">
                  {product.name}
                </h1>

                {/* Preço */}
                <div className="mb-8">
                  <p className="text-gray-400 text-sm mb-2">Preço</p>
                  <p className="text-5xl font-bold text-red-600">
                    R$ {parseFloat(product.price).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>

                {/* Descrição */}
                <div className="mb-8">
                  <p className="text-gray-400 text-sm mb-2">Descrição</p>
                  <p className="text-gray-300 leading-relaxed">
                    {product.description || "Sem descrição disponível"}
                  </p>
                </div>

                {/* Estoque */}
                <div className="mb-8 p-4 rounded-lg border border-red-600/30 bg-red-950/20">
                  <p className="text-gray-400 text-sm mb-1">Disponibilidade</p>
                  <p className={`font-semibold ${product.stock > 0 ? "text-green-400" : "text-red-400"}`}>
                    {product.stock > 0 ? `${product.stock} unidades em estoque` : "Fora de estoque"}
                  </p>
                </div>

                {/* Quantidade */}
                <div className="mb-8">
                  <p className="text-gray-400 text-sm mb-3">Quantidade</p>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={product.stock === 0}
                      className="w-12 h-12 rounded border border-red-600/30 text-white hover:bg-red-600/20 disabled:opacity-50 disabled:cursor-not-allowed transition"
                    >
                      −
                    </button>
                    <input
                      type="number"
                      min="1"
                      max={product.stock}
                      value={quantity}
                      onChange={(e) => setQuantity(Math.min(product.stock, Math.max(1, parseInt(e.target.value) || 1)))}
                      disabled={product.stock === 0}
                      className="w-20 h-12 rounded border border-red-600/30 bg-slate-900 text-white text-center disabled:opacity-50 disabled:cursor-not-allowed"
                    />
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      disabled={product.stock === 0}
                      className="w-12 h-12 rounded border border-red-600/30 text-white hover:bg-red-600/20 disabled:opacity-50 disabled:cursor-not-allowed transition"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Botão Adicionar ao Carrinho */}
                <Button
                  onClick={handleAddToCart}
                  disabled={product.stock === 0}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  {addedToCart ? "Adicionado ao Carrinho!" : "Adicionar ao Carrinho"}
                </Button>

                {/* Link para Carrinho */}
                {addedToCart && (
                  <Link href="/cart">
                    <Button variant="outline" className="w-full mt-3 border-red-600 text-red-500 hover:bg-red-600/10">
                      Ir para Carrinho
                    </Button>
                  </Link>
                )}
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
