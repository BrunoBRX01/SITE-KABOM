import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Admin() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [showAddProduct, setShowAddProduct] = useState(false);
  const utils = trpc.useUtils();
  const deleteProductMutation = trpc.products.delete.useMutation();
  const updateOrderStatusMutation = trpc.orders.updateStatus.useMutation();

  const { data: products, isLoading: productsLoading } = trpc.products.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: orders } = trpc.orders.list.useQuery();

  // Redirect if not admin using useEffect
  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      setLocation("/");
    }
  }, [loading, user, setLocation]);

  const handleDeleteProduct = (productId: number, productName: string) => {
    if (confirm(`Tem certeza que deseja deletar "${productName}"?`)) {
      deleteProductMutation.mutate(productId, {
        onSuccess: () => {
          alert("Produto deletado com sucesso!");
          utils.products.list.invalidate();
        },
        onError: (error) => {
          alert(`Erro ao deletar produto: ${error.message}`);
        },
      });
    }
  };

  const handleUpdateOrderStatus = (orderId: number, newStatus: string) => {
    updateOrderStatusMutation.mutate(
      { orderId, status: newStatus },
      {
        onSuccess: () => {
          alert("Status do pedido atualizado com sucesso!");
          utils.orders.list.invalidate();
        },
        onError: (error) => {
          alert(`Erro ao atualizar status: ${error.message}`);
        },
      }
    );
  };

  // Return null while loading or redirecting
  if (loading || !user || user.role !== "admin") {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <p className="text-slate-400">Gerencie produtos, pedidos e configurações da loja</p>
        </div>

        <Tabs defaultValue="products" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800 border border-cyan-500/20">
            <TabsTrigger value="products" className="text-slate-300 data-[state=active]:bg-cyan-500 data-[state=active]:text-black">
              Produtos
            </TabsTrigger>
            <TabsTrigger value="orders" className="text-slate-300 data-[state=active]:bg-cyan-500 data-[state=active]:text-black">
              Pedidos
            </TabsTrigger>
            <TabsTrigger value="categories" className="text-slate-300 data-[state=active]:bg-cyan-500 data-[state=active]:text-black">
              Categorias
            </TabsTrigger>
          </TabsList>

          {/* Produtos Tab */}
          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Gerenciar Produtos</h2>
              <Button
                className="bg-cyan-500 hover:bg-cyan-600 text-black font-semibold"
                onClick={() => setShowAddProduct(!showAddProduct)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Novo Produto
              </Button>
            </div>

            {showAddProduct && (
              <Card className="border-cyan-500/20 bg-slate-900/50 p-6">
                <h3 className="mb-4 text-lg font-semibold text-white">Adicionar Novo Produto</h3>
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Nome do produto"
                    className="w-full rounded bg-slate-800 px-3 py-2 text-white placeholder-slate-500 border border-slate-700"
                  />
                  <textarea
                    placeholder="Descrição"
                    className="w-full rounded bg-slate-800 px-3 py-2 text-white placeholder-slate-500 border border-slate-700"
                  />
                  <input
                    type="number"
                    placeholder="Preço"
                    className="w-full rounded bg-slate-800 px-3 py-2 text-white placeholder-slate-500 border border-slate-700"
                  />
                  <input
                    type="number"
                    placeholder="Estoque"
                    className="w-full rounded bg-slate-800 px-3 py-2 text-white placeholder-slate-500 border border-slate-700"
                  />
                  <select className="w-full rounded bg-slate-800 px-3 py-2 text-white border border-slate-700">
                    <option>Selecionar Categoria</option>
                    {categories?.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                  <input
                    type="url"
                    placeholder="URL da imagem"
                    className="w-full rounded bg-slate-800 px-3 py-2 text-white placeholder-slate-500 border border-slate-700"
                  />
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold">
                      Salvar
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setShowAddProduct(false)}
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              </Card>
            )}

            {productsLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
              </div>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-cyan-500/20">
                <table className="w-full">
                  <thead className="bg-slate-900 border-b border-cyan-500/20">
                    <tr>
                      <th className="px-4 py-3 text-left text-white font-semibold">Nome</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Categoria</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Preço</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Estoque</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {products?.map((product) => (
                      <tr key={product.id} className="hover:bg-slate-800/50">
                        <td className="px-4 py-3 text-slate-300">{product.name}</td>
                        <td className="px-4 py-3 text-slate-300">{product.categoryId}</td>
                        <td className="px-4 py-3 text-cyan-400 font-semibold">
                          R$ {parseFloat(product.price as any).toLocaleString("pt-BR")}
                        </td>
                        <td className="px-4 py-3 text-slate-300">{product.stock}</td>
                        <td className="px-4 py-3">
                          <Button
                            size="sm"
                            variant="destructive"
                            className="bg-red-600 hover:bg-red-700"
                            onClick={() => handleDeleteProduct(product.id, product.name)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Pedidos Tab */}
          <TabsContent value="orders" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Gerenciar Pedidos</h2>
            {!orders ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
              </div>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-cyan-500/20">
                <table className="w-full">
                  <thead className="bg-slate-900 border-b border-cyan-500/20">
                    <tr>
                      <th className="px-4 py-3 text-left text-white font-semibold">ID</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Cliente</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Total</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Status</th>
                      <th className="px-4 py-3 text-left text-white font-semibold">Data</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {orders?.map((order) => (
                      <tr key={order.id} className="hover:bg-slate-800/50">
                        <td className="px-4 py-3 text-slate-300">#{order.id}</td>
                        <td className="px-4 py-3 text-slate-300">{order.customerName}</td>
                        <td className="px-4 py-3 text-cyan-400 font-semibold">
                          R$ {parseFloat(order.totalAmount as any).toLocaleString("pt-BR")}
                        </td>
                        <td className="px-4 py-3">
                          <select
                            value={order.status}
                            onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                            className="rounded bg-slate-800 px-2 py-1 text-sm text-white border border-slate-700"
                          >
                            <option value="pending">Pendente</option>
                            <option value="processing">Processando</option>
                            <option value="shipped">Enviado</option>
                            <option value="delivered">Entregue</option>
                            <option value="cancelled">Cancelado</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 text-slate-300">
                          {new Date(order.createdAt).toLocaleDateString("pt-BR")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Categorias Tab */}
          <TabsContent value="categories" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Categorias</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {categories?.map((category) => (
                <Card
                  key={category.id}
                  className="border-cyan-500/20 bg-slate-900/50 p-4"
                >
                  <h3 className="font-semibold text-white mb-2">{category.name}</h3>
                  <p className="text-sm text-slate-400 mb-4">{category.description}</p>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="w-full bg-red-600 hover:bg-red-700"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Deletar
                  </Button>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
