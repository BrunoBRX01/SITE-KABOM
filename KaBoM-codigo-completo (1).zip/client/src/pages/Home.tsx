import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Zap, Shield, Truck } from "lucide-react";

// Viltrumita theme: Black with red and white accents
export default function Home() {
  const { data: products } = trpc.products.list.useQuery();

  // Pegar apenas 6 produtos em destaque
  const featuredProducts = products?.slice(0, 6) || [];

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-red-900/20 blur-3xl" />
        <div className="relative">
          <div className="mx-auto max-w-4xl text-center">
          <h1 className="mb-4 text-5xl font-bold text-white">
            Bem-vindo à <span className="text-red-600">KaBoM</span>
          </h1>
          <div className="mb-8 flex justify-center">
            <img 
              src="/manus-storage/ChatGPTImage11demai.de2026,23_26_42_077671ae.png" 
              alt="KaBoM Logo" 
              className="h-48 w-auto drop-shadow-lg"
            />
          </div>
          <p className="mb-8 text-xl text-gray-300">
            As melhores peças de PC com os melhores preços do mercado
          </p>
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Link href="/catalog" asChild>
                <Button
                  size="lg"
                  className="bg-red-600 hover:bg-red-700 text-white font-bold"
                >
                  Explorar Catálogo
                </Button>
              </Link>
              <Button
                size="lg"
                variant="outline"
                className="border-red-600 text-red-600 hover:bg-red-600/10"
              >
                Saiba Mais
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-8 md:grid-cols-3">
            <Card className="border-red-600/50 bg-gray-900/50 p-6 backdrop-blur">
              <Zap className="mb-4 h-12 w-12 text-red-600" />
              <h3 className="mb-2 text-xl font-bold text-white">Alta Performance</h3>
              <p className="text-gray-400">
                Componentes de última geração para máximo desempenho
              </p>
            </Card>
            <Card className="border-red-600/50 bg-gray-900/50 p-6 backdrop-blur">
              <Shield className="mb-4 h-12 w-12 text-red-600" />
              <h3 className="mb-2 text-xl font-bold text-white">Garantia</h3>
              <p className="text-gray-400">
                Todos os produtos com garantia e suporte técnico
              </p>
            </Card>
            <Card className="border-red-600/50 bg-gray-900/50 p-6 backdrop-blur">
              <Truck className="mb-4 h-12 w-12 text-red-600" />
              <h3 className="mb-2 text-xl font-bold text-white">Entrega Rápida</h3>
              <p className="text-gray-400">
                Frete rápido para todo o Brasil
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-8 text-3xl font-bold text-white">Produtos em Destaque</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredProducts.map((product) => (
              <Card
                key={product.id}
                className="border-red-600/50 bg-gray-900/50 overflow-hidden backdrop-blur hover:border-red-600 transition-colors"
              >
                <div className="aspect-square bg-gradient-to-br from-gray-800 to-black flex items-center justify-center">
                  <div className="text-gray-600 text-center">
                    <Zap className="mx-auto h-12 w-12 mb-2" />
                    <p className="text-sm">{product.name}</p>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="mb-2 font-semibold text-white">{product.name}</h3>
                  <p className="mb-4 text-red-600 font-bold">
                    R$ {parseFloat(product.price as any).toLocaleString("pt-BR")}
                  </p>
                  <Link href="/catalog" asChild>
                    <Button className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold">
                      Ver Detalhes
                    </Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl rounded-lg border border-red-600/50 bg-gradient-to-r from-red-600/10 to-red-900/10 p-12 text-center backdrop-blur">
          <h2 className="mb-4 text-3xl font-bold text-white">
            Pronto para potencializar seu setup?
          </h2>
          <p className="mb-8 text-lg text-gray-300">
            Explore nosso catálogo completo e encontre as melhores peças para seu PC
          </p>
          <Link href="/catalog" asChild>
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold">
              Ir para Catálogo
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
