import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="md:hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 text-gray-300 hover:text-red-500"
      >
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {isOpen && (
        <div className="absolute left-0 right-0 top-16 border-b border-red-600/50 bg-black/95 p-4 space-y-2">
          <Link href="/" onClick={() => setIsOpen(false)}>
            <button className="block w-full text-left px-4 py-2 text-gray-300 hover:text-red-500 hover:bg-red-600/10 rounded font-medium">
              Início
            </button>
          </Link>
          <Link href="/catalog" onClick={() => setIsOpen(false)}>
            <button className="block w-full text-left px-4 py-2 text-gray-300 hover:text-red-500 hover:bg-red-600/10 rounded font-medium">
              Catálogo
            </button>
          </Link>
          {user?.role === "admin" && (
            <Link href="/admin" onClick={() => setIsOpen(false)}>
              <button className="block w-full text-left px-4 py-2 text-gray-300 hover:text-red-500 hover:bg-red-600/10 rounded font-medium">
                Painel Admin
              </button>
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
