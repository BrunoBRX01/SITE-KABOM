import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-black border-t-4 border-red-600">
      {/* Newsletter Section - Vermelho Vibrante */}
      <div className="bg-gradient-to-r from-red-700 via-red-600 to-red-700 py-8 border-b-2 border-red-900">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-4 md:grid-cols-2 items-center">
            <div>
              <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-wider">
                KaBoM News
              </h3>
              <p className="text-white font-semibold">Receba as melhores ofertas em peças de PC</p>
            </div>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Digite seu e-mail"
                className="flex-1 rounded bg-black px-4 py-3 text-white placeholder-gray-500 border-2 border-white font-bold focus:outline-none"
              />
              <button className="bg-black hover:bg-red-900 text-red-600 hover:text-white font-black px-6 py-3 rounded border-2 border-white transition uppercase">
                Inscrever
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Links Section */}
      <div className="py-12 bg-black">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-5">
            {/* Atendimento */}
            <div className="border-l-4 border-red-600 pl-4">
              <h4 className="font-black text-red-600 mb-4 flex items-center gap-2 uppercase text-sm">
                <Phone className="h-5 w-5" />
                Atendimento
              </h4>
              <div className="space-y-2 text-sm">
                <p className="text-white font-bold">Segunda a Sexta</p>
                <p className="text-red-500 font-black text-lg">09:00 - 20:00</p>
                <p className="text-white font-bold mt-3">Sábado e Domingo</p>
                <p className="text-red-500 font-black text-lg">10:00 - 18:00</p>
              </div>
            </div>

            {/* Loja Física */}
            <div className="border-l-4 border-red-600 pl-4">
              <h4 className="font-black text-red-600 mb-4 flex items-center gap-2 uppercase text-sm">
                <MapPin className="h-5 w-5" />
                Loja Física
              </h4>
              <div className="space-y-2 text-sm">
                <p className="text-white font-bold">Av. Getúlio Vargas, 1500</p>
                <p className="text-white font-bold">Cuiabá - MT</p>
                <p className="text-red-500 font-black text-lg mt-2">(65) 3000-0000</p>
              </div>
            </div>

            {/* Sobre */}
            <div className="border-l-4 border-red-600 pl-4">
              <h4 className="font-black text-red-600 mb-4 uppercase text-sm">Sobre KaBoM</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Quem Somos
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Blog KaBoM
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Afiliados
                    </span>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Políticas */}
            <div className="border-l-4 border-red-600 pl-4">
              <h4 className="font-black text-red-600 mb-4 uppercase text-sm">Políticas</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Privacidade
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Termos de Uso
                    </span>
                  </Link>
                </li>
                <li>
                  <Link href="/">
                    <span className="text-white hover:text-red-500 transition cursor-pointer font-semibold">
                      Código de Conduta
                    </span>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Redes Sociais */}
            <div className="border-l-4 border-red-600 pl-4">
              <h4 className="font-black text-red-600 mb-4 uppercase text-sm">Siga-nos</h4>
              <div className="flex gap-2 flex-wrap">
                <a
                  href="https://www.facebook.com/kabom"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-red-600 hover:bg-red-700 text-white p-3 rounded font-black transition transform hover:scale-110"
                  title="Facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a
                  href="https://www.instagram.com/kabom"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-red-600 hover:bg-red-700 text-white p-3 rounded font-black transition transform hover:scale-110"
                  title="Instagram"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="https://www.twitter.com/kabom"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-red-600 hover:bg-red-700 text-white p-3 rounded font-black transition transform hover:scale-110"
                  title="Twitter"
                >
                  <Twitter className="h-5 w-5" />
                </a>
                <a
                  href="https://www.youtube.com/kabom"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-red-600 hover:bg-red-700 text-white p-3 rounded font-black transition transform hover:scale-110"
                  title="Youtube"
                >
                  <Youtube className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="h-1 bg-gradient-to-r from-red-600 via-red-700 to-red-600"></div>

      {/* Bottom Section */}
      <div className="py-6 bg-black border-t-2 border-red-600">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm font-bold text-red-600">
              © 2026 KaBoM - PEÇAS DE HARDWARE. TODOS OS DIREITOS RESERVADOS.
            </p>
            <div className="flex gap-3 items-center flex-wrap justify-center">
              <span className="text-xs font-black text-red-600 uppercase">Formas de Pagamento:</span>
              <div className="flex gap-2">
                <div className="bg-red-600 px-3 py-1 rounded text-xs text-black font-black">PIX</div>
                <div className="bg-red-600 px-3 py-1 rounded text-xs text-black font-black">CARTÃO</div>
                <div className="bg-red-600 px-3 py-1 rounded text-xs text-black font-black">BOLETO</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
