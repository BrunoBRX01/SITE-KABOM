import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Microchip, ShoppingCart, LogOut } from "lucide-react";
import MobileNav from "./MobileNav";

// Viltrumita theme: Black background with red and white accents
export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 border-b border-red-600/50 bg-black/95 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2">
              <img 
                src="/manus-storage/ChatGPTImage11demai.de2026,23_26_42_077671ae.png" 
                alt="KaBoM Logo" 
                className="h-14 w-auto"
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-gray-300 hover:text-red-500 transition-colors font-medium">
              Início
            </Link>
            <Link href="/catalog" className="text-gray-300 hover:text-red-500 transition-colors font-medium">
              Catálogo
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin" className="text-gray-300 hover:text-red-500 transition-colors font-medium">
                Painel Admin
              </Link>
            )}
          </nav>

          {/* Mobile Navigation */}
          <MobileNav />

          {/* Right Side */}
          <div className="flex items-center gap-4">
            <Link href="/cart">
              <Button
                variant="ghost"
                size="icon"
                className="text-gray-300 hover:text-red-500 hover:bg-red-600/10"
                asChild
              >
                <span>
                  <ShoppingCart className="h-5 w-5" />
                </span>
              </Button>
            </Link>

            {user ? (
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-300">{user.name}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-gray-300 hover:text-red-500"
                  onClick={() => logout()}
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Button
                size="sm"
                className="bg-red-600 hover:bg-red-700 text-white font-semibold"
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Entrar
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
