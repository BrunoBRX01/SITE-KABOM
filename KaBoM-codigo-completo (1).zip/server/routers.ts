import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  getAllProducts,
  getProductById,
  getProductsByCategory,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllCategories,
  getCategoryById,
  createCategory,
  getAllOrders,
  getOrderById,
  createOrder,
  updateOrderStatus,
} from "./db";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Produtos
  products: router({
    list: publicProcedure.query(() => getAllProducts()),
    getById: publicProcedure.input(z.number()).query(({ input }) => getProductById(input)),
    getByCategory: publicProcedure.input(z.number()).query(({ input }) => getProductsByCategory(input)),
    create: adminProcedure
      .input(
        z.object({
          name: z.string().min(1),
          description: z.string().optional(),
          price: z.string(),
          stock: z.number().int().min(0),
          categoryId: z.number().int(),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(({ input }) =>
        createProduct({
          name: input.name,
          description: input.description,
          price: input.price as any,
          stock: input.stock,
          categoryId: input.categoryId,
          imageUrl: input.imageUrl,
        })
      ),
    update: adminProcedure
      .input(
        z.object({
          id: z.number().int(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.string().optional(),
          stock: z.number().int().optional(),
          categoryId: z.number().int().optional(),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return updateProduct(id, data as any);
      }),
    delete: adminProcedure.input(z.number().int()).mutation(({ input }) => deleteProduct(input)),
  }),

  // Categorias
  categories: router({
    list: publicProcedure.query(() => getAllCategories()),
    getById: publicProcedure.input(z.number()).query(({ input }) => getCategoryById(input)),
    create: adminProcedure
      .input(z.object({ name: z.string().min(1), description: z.string().optional() }))
      .mutation(({ input }) => createCategory(input)),
  }),

  // Pedidos
  orders: router({
    list: adminProcedure.query(() => getAllOrders()),
    getById: protectedProcedure.input(z.number()).query(({ input }) => getOrderById(input)),
    create: publicProcedure
      .input(
        z.object({
          customerName: z.string().min(1),
          customerEmail: z.string().email(),
          customerPhone: z.string().optional(),
          address: z.string().min(1),
          city: z.string().min(1),
          state: z.string().min(2).max(2),
          zipCode: z.string().min(1),
          shippingMethod: z.enum(["sedex", "pac", "pickup"]),
          paymentMethod: z.enum(["credit_card", "pix", "boleto", "mercado_pago"]),
          shippingCost: z.string(),
          items: z.array(
            z.object({
              productId: z.number().int(),
              quantity: z.number().int().min(1),
              priceAtPurchase: z.string(),
            })
          ),
          totalAmount: z.string(),
        })
      )
      .mutation(({ input, ctx }) => {
        const orderData = {
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          customerPhone: input.customerPhone,
          address: input.address,
          city: input.city,
          state: input.state,
          zipCode: input.zipCode,
          shippingMethod: input.shippingMethod,
          paymentMethod: input.paymentMethod,
          shippingCost: input.shippingCost as any,
          totalAmount: input.totalAmount as any,
          userId: ctx.user?.id,
          status: "pending" as const,
        };
        const items = input.items.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          priceAtPurchase: item.priceAtPurchase as any,
        }));
        return createOrder(orderData, items);
      }),
    updateStatus: adminProcedure
      .input(z.object({ orderId: z.number().int(), status: z.string() }))
      .mutation(({ input }) => updateOrderStatus(input.orderId, input.status)),
  }),
});

export type AppRouter = typeof appRouter;
